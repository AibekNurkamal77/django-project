from django import forms
from .models import News
from django.views.generic import ListView

class NewsForm(forms.ModelForm):
    class Meta:
        model = News
        fields = ['title', 'content', 'price', 'is_published', 'category']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'contend': forms.Textarea(attrs={'class': 'form-control', 'rows': 5}),
            'price': forms.TextInput(attrs={'class': 'form-control'}),
            'category': forms.Select(attrs={'class': 'form-control'}),
        }

