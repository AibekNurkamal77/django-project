from django.shortcuts import render, get_object_or_404, redirect
from datetime import datetime, timedelta
from django.views.generic import ListView

from .models import News, Category, ComingSoon, SuperDeal
from .forms import NewsForm


class HomeNews(ListView):
    model = News
    template_name = 'news/E-Com_home.html'
    context_object_name = 'news'

    def get_queryset(self):
        is_pub = News.objects.filter(is_published=True)
        return is_pub

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Главная странитца'
        return context


class CategoryNews(ListView):
    model = News
    template_name = 'news/E-Com_shop.html'
    context_object_name = 'news'
    allow_empty = False

    def get_queryset(self):
        return News.objects.filter(category_id = self.kwargs['category_id'], is_published=True)

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = Category.objects.get(pk=self.kwargs['category_id'])
        return context

# def get_category(request, category_id):
#     news = News.objects.filter(category_id=category_id)
#     category = Category.objects.get(pk=category_id)
#
#     return render(request, 'news/category.html', {'news': news, 'category': category})

def view_news(request, news_id):
    item_news = get_object_or_404(News, pk=news_id)
    return render(request, 'news/E-Com_simple.html', {'item_news': item_news})


class ComingSoonNews(ListView):
    model = SuperDeal
    template_name = 'news/E-Com_home.html'
    context_object_name = 'news'

    def get_queryset(self):

        value = SuperDeal.objects.filter(created_at = self.kwargs['created_at'])

        expired = value + datetime.timedelta(hours=3, minutes=21)

        value = SuperDeal.objects.filter( created_at= expired )

        return value


# def add_book(request):
#     if request.method == 'POST':
#         form = NewsForm(request.POST)
#         if form.is_valid():
#             news = News.objects.create(**form.cleaned_data)
#             return redirect(news)
#     else:
#         form = NewsForm()
#     return render(request, 'news/add_book.html', {'form': form})


def add_news(request):
    if request.method == 'POST':
        form = NewsForm(request.POST)
        if form.is_valid():
            news = form.save()
            return redirect(news)
    else:
        form = NewsForm()
    return render(request, 'news/add_news.html', {'form': form})


