from django import template
import datetime

from news.models import News, Category, ComingSoon, SuperDeal

register = template.Library()


@register.filter(name='split_info')
def split_info(value):

    result = value.split(';')

    return result


@register.filter(name='data_eq')
def data_eq(value):
    expired = value + datetime.timedelta(hours=3, minutes=21)
    result = expired.timestamp() > datetime.datetime.now().timestamp()

    return result


@register.filter(name='data_plus')
def data_plus(value):
    result = value + datetime.timedelta(hours=3, minutes=21)

    return result


@register.filter(name='persent_n')
def persent_n(value):
    result = 19 * 100 / value
    return int(result)


@register.simple_tag(name='get_list_category')
def get_categoryes():
    return Category.objects.all()


@register.inclusion_tag('news/list_categories.html')
def show_categories():
    categories = Category.objects.all()[0:4]
    return {'categories': categories}


@register.inclusion_tag('news/E-Com_Soon.html')
def coming_soon_show():
    com_soon = ComingSoon.objects.all()
    return {'soon': com_soon}


@register.inclusion_tag('news/E-Com_SuperDeal.html')
def super_deal_show():
    super_deal = SuperDeal.objects.all()

    return {'super_deal': super_deal}


@register.inclusion_tag('news/E-shop_list.html')
def shop_featured_show():
    featured = News.objects.filter(new_coming=True)

    return {'featured': featured}

# @register.inclusion_tag('news/list_book_category.html')
# def show_categories():
#     categories = Category.objects.all()[0:3]
#     cate = Category.objects.all()[0:3]
#     return {'categories': categories}
