from django.contrib import admin

from .models import *
# Register your models here.


class NewsAdmin(admin.ModelAdmin):
    list_display = ('id', 'new_coming', 'title', 'category', 'creared_at', 'update_at', 'is_published',
                    'info_b', 'availability')
    list_display_links = ('id', 'new_coming', 'title', 'category')
    search_fields = ('id', 'title')
    list_editable = ('is_published',)
    list_filter = ('is_published', 'category')


class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'title')
    list_display_links = ('id', 'title')
    search_fields = ('title',)


class SoonAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'small_definition', 'photo')
    list_display_links = ('id', 'title')
    search_fields = ('title',)


class SuperDealsAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'number_val', 'created_at', 'photo_n1', 'photo_n2', 'photo_n3', 'photo_n4',
                    'cur_price', 'deal_price')
    list_display_links = ('id', 'title')
    search_fields = ('id', 'title',)


admin.site.register(News, NewsAdmin)
admin.site.register(Category, CategoryAdmin)
admin.site.register(ComingSoon, SoonAdmin)
admin.site.register(SuperDeal, SuperDealsAdmin)
