from django.db import models

from django.urls import reverse

class News(models.Model):
    title = models.CharField(max_length=150, verbose_name= 'Наеменования')
    content = models.TextField(blank=True, verbose_name= 'Контент')
    info_b = models.TextField(blank=True, verbose_name= 'Информатция о книге',
                              help_text='<i>Количество страниц</i></br>'
                                        '<i>Дата выхода</i></br>'
                                        '<i>Бумага</i></br>'
                                        '<i>Язык</i></br>'
                                        '<i>Формат книги</i>')
    availability=new_coming = models.BooleanField(default=True, verbose_name='Доступность')
    creared_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата Публикатции')
    update_at = models.DateTimeField(auto_now=True, verbose_name='Обновления')
    photo = models.ImageField(upload_to='photo/%Y/%m/%d/', verbose_name='Картинки', blank=True)
    price = models.IntegerField(blank=True, verbose_name='Цена')
    is_published = models.BooleanField(default=True, verbose_name='Опубликовано')
    new_coming = models.BooleanField(default=False, verbose_name='Новые поступления')
    category = models.ForeignKey('Category', on_delete=models.PROTECT, verbose_name='Категория')


    def get_absolute_url(self):
        return reverse('view_news', kwargs={'news_id': self.pk})


    def __str__(self):
        return self.title


    class Meta:
        verbose_name = 'Новость'
        verbose_name_plural = 'Новости'
        ordering = ['-creared_at']


class Category(models.Model):
    title = models.CharField(max_length=150, db_index=True, verbose_name="Наеменования Категория")

    def get_absolute_url(self):
        return reverse('category', kwargs={'category_id': self.pk})


    def __str__(self):
        return self.title


    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'
        ordering = ['title']


class ComingSoon(models.Model):
    title = models.CharField(max_length=100, verbose_name='Имя нового продукта')
    small_definition = models.CharField(max_length=300, verbose_name='Краткое описания')
    photo_soon = models.ImageField(upload_to='img-soon/%Y/%m/%d', blank=True, verbose_name='Фото')
    price_soon = models.IntegerField(blank=True, verbose_name='Цена')


    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Скора в библиотеке'
        verbose_name_plural = 'Скора в библиотеке'
        ordering = ['title']


class ComingSoon(models.Model):
    title = models.CharField(max_length=100, verbose_name='Имя нового продукта')
    small_definition = models.CharField(max_length=300, verbose_name='Краткое описания')
    photo = models.ImageField(upload_to='img_soon/%Y/%m/%d', blank=True, verbose_name='Фото')
    price_soon = models.IntegerField(blank=True, verbose_name='Цена')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Скора в библиотеке и Распродажа'
        verbose_name_plural = 'Скора в библиотеке'
        ordering = ['title']


class SuperDeal(models.Model):
    title = models.CharField(max_length=100, verbose_name='Имя нового продукта')
    number_val = models.IntegerField(verbose_name='Количество')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Срок годности')
    photo_n1 = models.ImageField(upload_to='suoer_deal/%Y/%m/%d', blank=True, verbose_name='Главная картинка')
    photo_n2 = models.ImageField(upload_to='suoer_deal/%Y/%m/%d', blank=True, verbose_name='Второя картинка')
    photo_n3 = models.ImageField(upload_to='suoer_deal/%Y/%m/%d', blank=True, verbose_name='Третия картинка')
    photo_n4 = models.ImageField(upload_to='suoer_deal/%Y/%m/%d', blank=True, verbose_name='Четвертая картинка')
    cur_price = models.IntegerField(blank=True, verbose_name='Прежная цена')
    deal_price = models.IntegerField(blank=True, verbose_name='Новая цена')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Супер цена'
        verbose_name_plural = 'Супер цена'
        ordering = ['title', 'created_at']